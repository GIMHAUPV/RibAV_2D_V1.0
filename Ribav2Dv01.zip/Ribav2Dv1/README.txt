RibAV 2D INPUTS: (Data/INPUTS)
------------------------------


Data/INPUTS/Hydromet:
--------------------

WteMaps.csv - The relative paths of the WTE maps have to be defined for each reference flow value
Hydromet.csv

	Every row corresponds to a specific day. The first row is described bellow:
	Column 1: 01/01/1983 = Date (DD/MM/aaaa)
	Column 2: 0 = Daily Precipitation (mm)
	Column 3: 0.899850498 = Daily Potential Evapotranspiration (mm)
	Column 4: 1.230261914 = Daily flow (m3/s)

Wte.asc - Ascii maps corresponding to specific flow values


Data/INPUTS/Maps:
----------------

DemMap.asc - Digital Elevation Model of the study site

SoilMap.asc - Soil type for each cell

InitialVegetationMap.asc - PFTs observed on field


Data/INPUTS/Parameters:
----------------------

SoilParameters.csv

	Every row corresponds to a specific soil type. The first row is described bellow:
	Column 1: 1 = Soil type
	Column 2: 0.397 = Porosity [ ]
	Column 3: 0.530 = Porosity Index [ ]
	Column 4: 3.847 = Bubble Pressure [Kpa]
	Column 5: 56.24 = Soil Saturated Hydraulic Conductivity [mm/hr]
	Column 6: 0.131 = Field Capacity Moisture (Typical value, moisture to 33 Kpa) [ ]
	Column 7: Soil1 = Soil type description
	Column 8: 17 = Soil depth to be considered in the Capillary Water Rise [m]

VegetationParameters.csv

	Every row corresponds to a specific PFT. The first row is described bellow:

	Column 1: 1 = Plant functional type number
	Column 2: 0.8 = Maximum Root Depth [m]
	Column 3: 0.7 = Effective Root Depth [m]
	Column 4: -0.75 = Saturation Extinction Depth [m], this value is <0 when the PFT can endure water elevations over the surface elevation
	Column 5: 0.8 = Transpiration Factor from the unsaturated Zone [ ], the value must be between 0 and 1
	Column 6: 0.6 = Transpiration Factor from the saturated Zone [ ], the value must be between 0 and 1
	Column 6: 1 = Plant cover, the value must be between 0 and 1 	
	Column 8: 0.97 = Maximum Soil-Root Water Conductance [mmMpa-1h-1]
	Column 9: 1500 = Permanent Wilting Point Pressure [KPa]
	Column 10: 500 = Critical Moisture Pressure [KPa]
	Column 11: RH = Plant functional type name
	Column 12: Riparian herbs = Plant functional type (PFT) description
	
Data\Kohen\INPUT:
-----------------

ObservedVegetationMap.asc - PFTs observed on field (is the same map as InitialVegetationMap.asc)







RibAV 2D OUTPUTS
----------------

Data/OUTPUT/EtindexMaps:
-----------------------
The ETidx shows the real evapotranspiration average rate (referred to the potential evapotranspiration),for the simulation time period. 
The zonation hypothesis assumes that the most favoured PFT is the one with higher ETidx. 
The model outputs are the ETidx maps for each PFT, the final ETidx map (ETidx value corresponding to the simulated PFT), and the simulated vegetation map


	AverageETindexMap_fromVegType_1.asc
	AverageETindexMap_fromVegType_2.asc
	AverageETindexMap_fromVegType_3.asc
	AverageETindexMap_fromVegType_4.asc
	
	Simulated ETIndex Map.asc
	Simulated Vegetation Map.asc
	

Data\Kohen\OUTPUT:
-----------------

The program also calculates the Cohen's kappa (Coefficient of agreement for nominal variables. Cohen, 1960) and shows the confusion matrix in the DataFile.csv output.
In addition, an AccuracyMap.asc is created to observe the agreement between observed and simulated vegetation
